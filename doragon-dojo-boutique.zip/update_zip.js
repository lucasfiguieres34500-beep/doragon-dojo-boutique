const { execSync } = require('child_process');
execSync("powershell -NoProfile -Command \"Get-ChildItem -Path '.' -Exclude 'node_modules','*.zip' | Compress-Archive -DestinationPath 'doragon-dojo-boutique.zip' -Force\"");
console.log('Zip updated successfully!');
